<?php
  include './delete.php';
  if( 
    empty($_SESSION['user_id'] ) ||
    empty($_SESSION['username'] )
  ){
    header("Location:".URL."login/login/login.php");
    exit();
  }

  $loginUserId = $_SESSION['user_id'];

  $queryparameter = "";
  $and = "";
  $orderBy = !empty( $_GET['order_by'] ) ? $_GET['order_by'] : 'id';
  $order   = !empty( $_GET['order'] )   ? $_GET['order'] : 'desc';
  $page    = !empty( $_GET['page'] )   ? $_GET['page'] :1;

  $page    = ($page <= 0) ? 1 : $page;

  $search = "";

  $perpage = 1;
  
  if( !empty($_GET['search']) ){
    $search = $_GET['search'];
   
    $queryparameter= " WHERE (`firstname` LIKE '%{$search}%' OR `username` LIKE '%{$search}%' OR `email` LIKE '%{$search}%' OR `country` LIKE '%{$search}%' OR `qualification` LIKE '%{$search}%') AND";
  }else{
    $and = "WHERE ";
  }

  $start_from = ($page-1) * $perpage;


  $sql = "
    SELECT
    SQL_CALC_FOUND_ROWS
    * 
    FROM 
      `".TABLE."`
      {$queryparameter}
      {$and}
      `id` <> {$loginUserId}
    ORDER BY 
      `{$orderBy}` 
    {$order}
  limit
  {$start_from },{$perpage}
  ";

  // $sql= "SELECT * FROM `".TABLE."`ORDER BY `id` DESC LIMIT 20";
  $fetchall = mysqli_query($mysql, $sql);
  $listing  = mysqli_fetch_all($fetchall, MYSQLI_ASSOC);

  $sort = ($order == 'desc') ? 'asc' :'desc';

  $statement  =  mysqli_query($mysql,'SELECT FOUND_ROWS() as total');
  $response   = mysqli_fetch_all($statement, MYSQLI_ASSOC);
  $totalpages = ceil( $response[0]['total'] / $perpage );

?>
<?php include './login/header.php'; ?>
  <!-- <ul class="customNav col-sm-15">
    <li>
      <form method="get">
        <div class="wrap">
          <div class="search">
              <input type="text" class="searchTerm" name = "search" placeholder="What are you looking for?">
              <button type="submit" class="searchButton" name= "searchButton"> Search <i class="fa fa-search"></i></button>
          </div>
        </div>
      </form>
    </li>
    <li><a href="http://localhost/login-main/login/signup/signup.php">Signup</a></li>
    <li><a href="http://localhost/login-main/login/login/login.php">Login</a></li>
    <li>
    <div class="dropdown">
      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Dropdown button
      </button>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item" href="#">Action</a>
        <a class="dropdown-item" href="#">Another action</a>
        <a class="dropdown-item" href="#">Something else here</a>
      </div>
    </div>
    </li>
  </ul> -->


<?php include PATH.DS.'login'.DS.'navBar.php'; ?>


<div class= "col-sm-15" style= "background: linear-gradient(to top right, #0066ff 0%, #66ff33 100%); height:100%;"> 
  <form method="post">
    <div>
      <select class="custom-select col-sm-2" name="bulkAction">
        <option value="">SELECT</option>
        <option value="deleted">Delete</option>
      </select>
      <button type="submit" class="btn-primary" name="bulk">Action</button>
    </div>
  </form>  
  <style>
    table, th, td { 
    text-align:center;
    margin-top: 10px;
    border: 1px solid black;
    }
  </style>
  <table style="width:100%; leangth: 100%; ">
    <thead>
      <tr>
        <th> <input type="checkbox"> </th>
        <th> Sr No. </th>
        <?php
          $tableheader = [
            //table field name => // display name
            'id'            => 'ID',
            'firstname'     => 'Name',
            'username'      => 'Username',
            'email'         => 'Email',
            'country'       => 'Country',
            'qualification' => 'Qualification',
            'password'      => 'Password'
          ];
          
          foreach($tableheader as $tablekey => $displayText){ ?>
            <th> 
              <a href="listing.php?order_by=<?php echo $tablekey; ?>&order=<?php echo $sort; ?>&page=<?php echo $page; ?>&search=<?php echo $search; ?>">
                <?php echo $displayText; ?>
              </a>
            </th>
          <?php } ?>

        <!-- <th>
          <a href="listing.php?order_by=firstname&order=<?php// echo $sort; ?>">Name</a>
        </th>
        <th> 
          <a href="listing.php?order_by=username&order=<?php// echo $sort; ?>">Username </a>
        </th>
        <th> 
          <a href="listing.php?order_by=email&order=<?php //echo $sort; ?>">Email </a> 
        </th>
        <th> 
          <a href="listing.php?order_by=country&order=<?php// echo $sort; ?>">Country</a> 
        </th>
        <th> 
          <a href="listing.php?order_by=qualification&order=<?php// echo $sort; ?>">Qualification</a> 
        </th>
        <th> 
          <a href="listing.php?order_by=password&order=<?php// echo $sort; ?>">Password </a> 
        </th> -->
        <th> Status </th>
        <th> Action </th>Previous
      </tr>
    </thead>
    <tbody>
 
      <?php
  
        // $count= 0;
        foreach($fetchall as $key => $value) {

        // echo "<pre>";
        //  print_r($key);
        // echo "</pre>";
      //  die(); &
          // itemsPerPage *(currentPage-1)$count+= 1;
      ?>
      <tr>
   
       <td><input type="checkbox" name="users[]" value="<?php echo $value ['id'] ?>"></td>
        <td><?php echo ($start_from+$key+1);?> </td>
        <td><?php echo $value['id'];?> </td>
        <td><?php echo $value['firstname']; ?> <?php echo $value['lastname']; ?></td>
        <td><?php echo $value['username']; ?></td>
        <td><?php echo $value['email']; ?></td>
        <td><?php echo $value['country']; ?></td>
        <td><?php echo $value['qualification']; ?></td>
        <td><?php echo $value['password']; ?></td>
        <td><?php echo ($value['activation'] == '1') ? '<svg height="10" width="10 "><circle cx="5" cy="5" r="3" fill="green" /></svg> ' : '<svg height="10" width="10 "><circle cx="5" cy="6" r="3" fill="red" /></svg>'; ?></td>

        <?php if( $_SESSION['user_status']  == 'admin' ){ ?>
          <td><a href= "edit.php?id= <?php echo $value ['id']; ?>">Edit </a>
        <a href="listing.php?id=<?php echo $value['id']; ?>&remove=delete">Delete</a> </td>
        <?php }else{ ?>
          <td><a href= "view.php?id= <?php echo $value ['id']; ?>">View </a></td>
        <?php } ?>
      </tr> 
      <?php
    }  
      ?>  
    </tbody>
  </table>
  <div class = "" >
    <?php

      // if($page > $totalpages){
      //   header("Location:http://localhost/login-main/login/listing.php?page={$totalpages}&search={$search}&order_by={$orderBy}&order={$order}");
      // }

      $prev = ($page > 1) ? $page - 1 : 1;
      $next =  ($totalpages > $page)? $page + 1 : $totalpages;

      $nextDisable = ($totalpages == $page) ? 'disabled' : '';
      $prevDisable = ($page == 1) ? 'disabled': '';
    ?>
    <nav aria-label="Page navigation example">
      <ul class="pagination justify-content-center">
        <li class="page-item <?php echo $prevDisable; ?>">
          <a class="page-link" href="listing.php?page=<?php echo $prev; ?>&search=<?php echo $search; ?>&order_by=<?php echo $orderBy; ?>&order=<?php echo $order; ?>" tabindex="-1">Previous</a>
        </li>
          <?php 
            for($j=1; $j <= $totalpages; $j++){ 
              $active = ($j == $page) ? 'active' : '';
              //$disablePageNumber = ($j == $page) ? 'disabled' : '';
              // $link   = '<a class="page-link" href="listing.php?page='.$j.'&search='.$search.'&order_by='.$orderBy.'&order='.$order.'>
              //   '.$j.'</a>';
              // if( $j > 5 ){
              //   $link = '...';
              // }
          ?>
            <li class="page-item <?php echo $active; ?>">
              <?php if($j <= 5){ ?>
                <a class="page-link" href="listing.php?page=<?php echo $j; ?>&search=<?php echo $search; ?>&order_by=<?php echo $orderBy; ?>&order=<?php echo $order; ?>">
                  <?php echo $j; ?>
                </a>
              <?php }elseif($j <=10){ echo '.'; }else{echo '';} ?>
            </li>
          <?php } ?>
        <li class="page-item <?php echo $nextDisable; ?> ">
          <a class="page-link" href="listing.php?page=<?php echo $next; ?>&search=<?php echo $search; ?>&order_by=<?php echo $orderBy; ?>&order=<?php echo $order; ?>">Next</a>
        </li>
      </ul>
    </nav>
  </div>
</div>


<button class="open-button" onclick="openForm()">Chat</button>

<div class="chat-popup" id="myForm">
  <form action="/action_page.php" class="form-container">
    <h1>Chat</h1>

    <label for="msg"><b>Message</b></label>
    <textarea placeholder="Type message.." name="msg" required></textarea>

    <button type="submit" class="btn">Send</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>
<?php include PATH.DS.'login'.DS.'login'.DS.'footer.php';  ?>