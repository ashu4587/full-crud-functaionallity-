<?php
  include './connection/connection.php';
  $message = "";
  if(isset($_GET['remove'] )&& ($_GET['remove']) == 'delete'){
    $validUser = false;

    if( $_SESSION['status'] != 'admin' ){
      $validUser = true;
      echo "you can not delete this record";
    }
    
    if($validUser == false){

      $id = $_GET['id'];
    
      $delete  = "DELETE FROM `".TABLE."` WHERE `id`=".$_GET['id'];
      $deleted = mysqli_query($mysql, $delete);
  
      if($deleted == true){
        echo "Record deleted succesfully";
      }else{
        echo "there is an error to delete record";
      }

    }
  }

  if(isset($_POST['bulkAction'] )&& $_POST['bulkAction'] == 'deleted'){ 
   

    if( empty( $_POST['users'] ) ){
      return;
    }

    $users= $_POST['users'];
    // echo "<pre>";
    //   print_r($users);
    // echo "</pre>";
    // die(); 

    #DELETE FROM `data` WHERE `id` in (3,2)

    $allUser  = implode(",",$users);
    // $records  = mysqli_query($mysql, "DELETE FROM `".TABLE."` WHERE `id` in ({$allUser})" );
    // if($records === false){
    //   return "Multi delete Error";
    // }   

    foreach ($users as $ids) {
      $records  = mysqli_query($mysql, "DELETE FROM `".TABLE."` WHERE `id` =".$ids );
      if($records === false){
        return "Multi delete Error";
      }      
    }
    echo "records deleted";
  }
?>