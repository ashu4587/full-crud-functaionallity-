<?php
  include './connection/connection.php';
  if( 
    empty($_SESSION['user_id'] ) &&
    empty($_SESSION['username'] )&&
    empty($_SESSION['email'] ) 
  ){
    header("Location:http://localhost/login-main/login/login/login.php");
  }

  $fetch = userStatus($_SESSION['user_id']);

  if(empty($fetch)){
    echo "Invalid User";
    die();
  }

  if( $fetch['status'] != 'admin' && $_SESSION['user_id'] != $_GET['id'] ){
    echo "<h1>Error : 404</h1><br> You can not access this URL";
    die();
  }

    // $frname= $_POST['firstname'];
    // $lsname= $_POST['lastname'];
    // $email= $_POST['email'];
    // $empty = "";
   
    // $flag = false;
  if(isset($_POST['update'])){
   
    // if(empty($frname)){
    //   $empty = "This field is required";
    //   $flag = false;
    // }
    // if(empty($lsname)) {
    //   $empty = "This field is required";
    //   $flag = false;
    // }
    // if(empty($email)) {
    //   $empty = "This field is required";
    //   $flag = false;
    // }else{
      $update    = "UPDATE `".TABLE."` SET `firstname`='".$_POST['firstname']."' , `lastname`='".$_POST['lastname']."' ,`email`='".$_POST['email']."' WHERE `id`=".$_GET['id'];  
      $updatecheck= mysqli_query($mysql, $update);
      if($updatecheck == false){
        echo "There is an error in updating data";
      }else{
        header("location:http://localhost/login-main/login/listing.php");
      }
    }
  //}
  $previousrecord  = mysqli_query($mysql, "SELECT * FROM `".TABLE."` WHERE `id` = ".$_GET['id']);
  $record   = mysqli_fetch_assoc($previousrecord );
  $quali = explode("," ,  $record ['qualification']);

  
?>
<div class="col-sm-5" style=" text-align: center;background: linear-gradient(to left, #00ccff 0%, #ff00ff 100%); height:100%;">
  <h1> EDIT </h1>

  <form action="" method="post">

    <div class="form-group">
      <label for="name">Firstname</label>
      <input type= "text" class= "form-control" name="firstname"  placeholder= "Enter your first name here" value="<?php echo $record ['firstname']; ?>"><br>
      <?php
          // if( !empty($empty)){
          //   echo $empty;
          // } 
      ?>
    
    <div class="form-group">
      <label for="name">Lastame</label>
      <input type= "text" class= "form-control" name="lastname"  placeholder= "Enter your last name here" value="<?php echo $record ['lastname']; ?>"><br>
      <?php
          // if( !empty($empty)){
          //   echo $empty;
          // } 
      ?>

   
      <label for="email">Email</label>
      <input type= "text" class= "form-control" name="email"  placeholder= "Enter your email here" value="<?php echo $record ['email']; ?>"><br>
      <?php
          // if( !empty($empty)){
          //   echo $empty;
          // } 
      ?>
   
   <label for="qualification"> <strong>Qualification </strong></label></br>
        <label for="10TH " class="checklabel">10TH </label> <input type="checkbox" class= "form-control" name="ch[]"  value="10TH <?php echo ( $quali[0] == '10TH' ) ? 'checked="checked"' : ''; ?>">
        <label for="12TH" class="checklabel">12TH </label> <input type="checkbox" class="form-control" name="ch[]"   value="12TH <?php echo ( $quali[0] == '12TH' ) ? 'checked="checked"' : ''; ?>">
        <label for="UG" class="checklabel">UG </label> <input type="checkbox" class= "form-control" name="ch[]"  value="UG <?php echo ( $quali[0] == 'UG' ) ? 'checked="checked"' : ''; ?>">
        <label for="PG" class="checklabel"> PG </label>  <input type="checkbox" class= "form-control" name="ch[]"  value="PG <?php echo ( $quali[0] == 'PG' ) ? 'checked="checked"' : ''; ?>">
      <div class="col-sm-2" >
      <button type= "submit" class= "vertical-center" name="update"   value="submit">UPDATE</button>
    </div>
    
  </form>
</div>
<?php include PATH.DS.'login'.DS.'login'.DS.'footer.php'; ?>