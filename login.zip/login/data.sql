-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 11, 2020 at 10:32 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` text NOT NULL,
  `email` text NOT NULL,
  `country` text NOT NULL,
  `password` text NOT NULL,
  `qualification` text NOT NULL,
  `activation` enum('0','1') NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `firstname`, `lastname`, `username`, `email`, `country`, `password`, `qualification`, `activation`, `status`, `created_on`, `updated_on`) VALUES
(4, 'ashi', 'sharma', 'ashu@6787', 'ruhani24255@gmail.com', 'sri-lanka', 'aSHU@4587', '10TH,12TH,PG,', '0', 'admin', '2020-11-04 10:16:39', '2020-11-11 08:13:26'),
(5, 'Ruhani', 'sharma', 'ashu12', 'ashu.kumar.6787@gmail.com', 'zimbambe', 'aSHU@4587', '12TH,UG,PG,', '0', '', '2020-11-04 10:18:53', '0000-00-00 00:00:00'),
(6, 'sunil', 'sharma', 'ashu4587', 'ashu.kumar.6787@gmail.com', 'india', 'Ashu@4587', '', '0', '', '2020-11-04 10:19:46', '2020-11-04 10:50:42'),
(7, 'Rahul', 'singh', 'Rahul', 'Rahul.singh335@gmail.com', 'india', 'Rahul@1234', '12TH,UG,PG,', '0', '', '2020-11-04 10:49:30', '2020-11-11 08:06:53'),
(8, 'Pallavi', 'mahajan', 'pallavi', 'pallu.345@gmail.com', 'india', 'Ashu@4587', '12TH,UG,PG,', '0', '', '2020-11-04 10:55:37', '2020-11-04 10:56:05'),
(9, 'sunil', 'kumar', 'ashu1223', 'ashu.kumar.6787@gmail.com', 'india', 'Ashu@4587', '', '0', '', '2020-11-04 11:01:34', '0000-00-00 00:00:00'),
(10, 'Ruhani', 'kumar', 'ashu4587a', 'ashu.kumar.6787@gmail.com', 'india', 'Ashu@4587', '', '0', '', '2020-11-04 11:04:00', '0000-00-00 00:00:00'),
(11, 'Ruhani', 'sharma', 'ashu@6787ss', 'ashu.kumar.6787@gmail.com', 'india', 'Ashu@4587', '12TH,PG,', '0', '', '2020-11-04 11:05:32', '0000-00-00 00:00:00'),
(12, 'sunil', 'kumar', 'ashu1012', 'ashu.kumar.6787@gmail.com', 'india', 'Ashu@4587', '10TH,12TH,', '0', '', '2020-11-04 11:26:53', '0000-00-00 00:00:00'),
(13, 'sunil', 'hello', 'ashu1234', 'ashu.kumar.6787@gmail.com', 'india', 'Ashu@4587', '10TH12THUG', '1', '', '2020-11-04 11:35:25', '2020-11-11 09:05:15'),
(14, 'Ruhani', 'kumar', 'ashu4587sssw', 'ashu.kumar.6787@gmail.com', 'india', 'Ashu@4587', '10TH12THUG', '0', '', '2020-11-04 11:36:11', '0000-00-00 00:00:00'),
(15, 'Ruhani', 'kumar', 'ashu4587sad', 'ashu.kumar.6787@gmail.com', 'india', 'Ashu@4587', '10TH,12TH,UG,PG', '0', '', '2020-11-04 11:39:03', '0000-00-00 00:00:00'),
(16, 'ashu', 'kumar', 'ashu4587452', 'ashu4587@gmail.com', 'india', 'Ashu@4587', '10TH,12TH,UG,PG', '0', '', '2020-11-04 11:39:34', '2020-11-06 12:49:20'),
(22, 'ashi', 'sharma', 'ashi', 'ruhani@gmail.com', 'india', 'Ashu@4587', '', '0', '', '2020-11-05 06:06:09', '2020-11-11 05:55:12'),
(23, 'prashant', 'thkr', 'pst123', 'pst@gmail.com', 'india', 'Qwettytyty333', '', '0', '', '2020-11-11 05:35:18', '0000-00-00 00:00:00'),
(24, 'Ruhani', 'hello', 'ashu4587455', 'ashu@gmail.com', 'india', 'Ashu@4587', '', '0', '', '2020-11-11 05:50:41', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
