<?php
   $session = mysqli_query($mysql, "SELECT * FROM `".TABLE."` WHERE `id` =".$_SESSION['user_id']);
   $fetch   = mysqli_fetch_assoc($session); 
?>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="logo-image">
    <img src="./aa.png" class="img-fluid">
  </div></a>
  <style>
    .logo-image{
    width: 46px;
    height: 46px;
    border-radius:50%;
    overflow: hidden;
    margin-top: -6px;
    }
  </style>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <form class="form-inline my-2 my-lg-0 col-sm-10" method="get">
      <input class="form-control mr-sm-2  col-sm-10" type="search" name = "search"   value= "<?php echo (!empty($search)) ?  $search : '';?>">
    </form>

    <ul class="navbar-nav mr-auto">
      <li class="nav-item dropdown">
        <i class="fa fa-bars nav-link " data-toggle="dropdown"></i>
        <!-- <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Dropdown
        </a> -->
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
         
          <p>
            <a class="dropdown-item" href="http://localhost/login-main/login/about.php">
            <?php 
              echo $fetch['firstname']."\t".$fetch['lastname']."\t"; 
              echo($_SESSION['status'] == '1') ? '<svg height="10" width="10 "><circle cx="5" cy="5" r="3" fill="green" /></svg>'     :'Deactive';
            ?></a>
          </p>
          <div class="dropdown-divider"></div>
          <p class="dropdown-item">
            <?php
              echo empty($_SESSION['user_status']) ? 'customer' : $_SESSION['user_status'];
            ?>
          </p>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="http://localhost/login-main/login/logout.php">logout</a>
        </div>
      </li>
    </ul>
  </div>
</nav>    