<html>
  <head> <title> login </title>
  </head>
  <body>
    <?php //<link rel="stylesheet" href="../css/styles.css"> ?>
    <link rel="stylesheet" href="<?php echo URL; ?>login/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo URL; ?>login/css/listing.css">
    <link rel="stylesheet" href="<?php echo URL; ?>login/css/search+about.css">
    <!-- <link rel="stylesheet" href="<?php// echo URL; ?>login/css/search.css"> -->
  
 

    