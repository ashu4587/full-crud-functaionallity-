<?php
  include '../connection/connection.php';
  $errorhandling =$errorhandling2 = "";
  if( 
    !empty($_SESSION['user_id'] ) ||
    !empty($_SESSION['username'] )
  ){
    header("Location:http://localhost/login-main/login/listing.php");
    exit();
  }

  if(isset($_POST['login'])){
    $pword = $_POST['password'];
    $uname = $_POST['username'];
    if(empty($uname)){
      $errorhandling= "*Please enter your username";
    }else{
      if(empty($pword)){
        $errorhandling2= "*Please enter your password";
      }else{
        $userquery= mysqli_query($mysql, "SELECT * FROM `".TABLE."` WHERE `username` ='$uname' AND `password`='$pword'");
      //   echo"<pre>";
      //   print_r($userquery);
      // echo"</pre>";
      // die(); 
      $row = mysqli_fetch_assoc($userquery);
      
      if(!empty($row)){
        $activation  = '1';
        $updatecheck = mysqli_query($mysql, "UPDATE `".TABLE."` SET `activation`='1' WHERE `id` = ".$row['id']);
        
        if( $updatecheck == false ){
          $activation = '0';
        }
       
        $_SESSION["user_id"]     = $row['id'];
        $_SESSION["username"]    = $row['username'];
        $_SESSION["status"]      = $activation;
        $_SESSION["user_status"] = $row['status'];
        header("Location:http://localhost/login-main/login/listing.php");
        exit();
       #TODO: go to listing page
        //exit;
      }else{
        echo"Sorry,invalid username or password , Please try again.";
      }

     
      }
    }
  }

  
  include PATH.DS.'login'.DS.'login'.DS.'header.php';
  include PATH.DS.'login'.DS.'login'.DS.'login-form2.php';
  include PATH.DS.'login'.DS.'login'.DS.'footer.php';
?>