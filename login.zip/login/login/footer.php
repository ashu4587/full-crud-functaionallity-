    <script src="<?php echo URL; ?>login/css/jquery.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>    
    <script src="<?php echo URL; ?>login/css/bootstrap.js"></script>
  </body>
</html>