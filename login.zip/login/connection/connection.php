<?php
  define('HOST', 'localhost');
  define('USER', 'root');
  define('PASS', '');
  define('DATA', 'data');
  define('TABLE', 'data');

  define('URL','http://localhost/login-main/');

  define('DS'  , DIRECTORY_SEPARATOR);


  # Path
  define( 'PATH' , dirname( dirname(dirname(__FILE__)) ) );

  $mysql= mysqli_connect(HOST, USER, PASS, DATA);
  if (mysqli_connect_error()){
    echo "failed to connect to database".mysqli_connect_error();
  }
  else{
    //echo "you are sucessfully connected to database";
  }

  // Session start
  session_start();

  function userStatus($id){
    global $mysql;
    $session = mysqli_query($mysql, "SELECT * FROM `".TABLE."` WHERE `id` =".$id);
    return mysqli_fetch_assoc($session);
  }
  
  function debug($args){
    echo "<pre>";
      print_r($args);
    echo "</pre>";
  }
?>