<?php
  include './delete.php';
  
  $queryparameter = "";

  $orderBy = !empty( $_GET['order_by'] ) ? $_GET['order_by'] : 'id';
  $order   = !empty( $_GET['order'] )   ? $_GET['order'] : 'desc';
  $page    = !empty( $_GET['page'] )   ? $_GET['page'] :1;

  $perpage =2;

  if( !empty($_GET['search']) ){
    $search = $_GET['search'];
    $queryparameter= " WHERE `username` LIKE '%{$search}%' OR `email` LIKE '%{$search}%'";
  }

  $start_from = ($page-1) * $perpage;
    // echo "<pre>";
    // var_dump($start_from);
    // echo "</pre>";
    // die();  

  $sql = "
    SELECT
    SQL_CALC_FOUND_ROWS
    * 
    FROM 
      `".TABLE."`
      {$queryparameter}
    ORDER BY 
      `{$orderBy}` 
    {$order}
  limit
  {$start_from },{$perpage}
  ";
  // var_dump($sql);
  // die();

  
  // $sql= "SELECT * FROM `".TABLE."`ORDER BY `id` DESC LIMIT 20";
  $fetchall = mysqli_query($mysql, $sql);
  $listing  = mysqli_fetch_all($fetchall, MYSQLI_ASSOC);

  $sort = ($order == 'desc') ? 'asc' :'desc';
?>
<?php include './login/header.php'; ?>
  <ul class="customNav col-sm-15">
    <li>
      <form method="get">
    <div class="wrap">
      <div class="search">
          <input type="text" class="searchTerm" name = "search" placeholder="What are you looking for?">
          <button type="submit" class="searchButton" name= "searchButton"> Search <i class="fa fa-search"></i></button>
      </div>
    </div>
    </form>
    </li>
    <li><a href="http://localhost/login-main/login/signup/signup.php">Signup</a></li>
    <li><a href="http://localhost/login-main/login/login/login.php">Login</a></li>
  
  </ul>

<div style= "background: linear-gradient(to top right, #0066ff 0%, #66ff33 100%); height:100%;  margin-top:60px"> 
<form method="post">
  <div>
    <select class="custom-select col-sm-2" name="bulkAction">
      <option value="">SELECT</option>
      <option value="deleted">Delete</option>
    </select>
    <button type="submit" class="btn-primary" name="bulk">Action</button>
  </div>
  <style>
    table, th, td { 
    text-align:center;
    margin-top: 10px;
    border: 1px solid black;
    }
  </style>
  <table style="width:100%; leangth: 100%; ">
    <thead>
      <tr>
        <th> <input type="checkbox"> </th>
        <th> Sr No. </th>
        <th>
          <a href="listing.php?order_by=firstname&order=<?php echo $sort; ?>">Name</a>
        </th>
        <th> 
          <a href="listing.php?order_by=username&order=<?php echo $sort; ?>">Username </a>
        </th>
        <th> 
          <a href="listing.php?order_by=email&order=<?php echo $sort; ?>">Email </a> 
        </th>
        <th> 
          <a href="listing.php?order_by=password&order=<?php echo $sort; ?>">Password </a> 
        </th>
        <th> Action </th>
      </tr>
    </thead>
    <tbody>
      <?php
        // $count= 0;
        foreach($fetchall as $key => $value) { 
        // echo "<pre>";
        //  print_r($key);
        // echo "</pre>";
      //  die(); 
          // itemsPerPage *(currentPage-1)$count+= 1;
      ?>
      <tr>
       <td><input type="checkbox" name="users[]" value="<?php echo $value ['id'] ?>"></td>
        <td><?php echo ($start_from+$key+1);?> </td>
        <td><?php echo $value['firstname']; ?> <?php echo $value['lastname']; ?></td>
        <td><?php echo $value['username']; ?></td>
        <td><?php echo $value['email']; ?></td>
        <td><?php echo $value['password']; ?></td>
        <td><a href= "edit.php?id= <?php echo $value ['id']; ?>">Edit </a>
        <a href="listing.php?id=<?php echo $value['id']; ?>&remove=delete">Delete</a> 
      </tr> 
      <?php 
      } 
      ?>  
    </tbody>
  </table>
</form>

</div>
<?php
  $statement  =  mysqli_query($mysql,'SELECT FOUND_ROWS() as total');
  $response   = mysqli_fetch_all($statement, MYSQLI_ASSOC);
  $totalpages = ceil( $response[0]['total'] / $perpage );
?>
<div class = "" >
  <nav aria-label="Page navigation example">
    <ul class="pagination justify-content-center">
      <!-- <li class="page-item disabled">
        <a class="page-link" href="#" tabindex="-1">Previous</a>
      </li> -->
        <?php for($j=1; $j <= $totalpages; $j++){ ?> 
          <li class="page-item">
            <a class="page-link" href="listing.php?page=<?php echo $j; ?>">
              <?php echo $j; ?>
            </a>
          </li>
        <?php } ?>
      <!-- <li class="page-item">
        <a class="page-link" href="#">Next</a>
      </li> -->
    </ul>
  </nav>
</div>
