<?php
  include './connection/connection.php';
  $updatecheck = mysqli_query($mysql, "UPDATE `".TABLE."` SET `activation`='0' WHERE `id` = ".$_SESSION['user_id']);
  unset($_SESSION["username"]);
  unset($_SESSION["user_id"]);
  unset($_SESSION["status"]);
  unset($_SESSION["user_status"]);
  session_destroy();
  header("Location:http://localhost/login-main/login/login/login.php");
?>