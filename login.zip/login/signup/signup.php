<?php

  // echo rtrim("mca,bca,mma,",",");
  // die();

  include '../connection/connection.php';
  if( 
    !empty($_SESSION['user_id'] ) ||
    !empty($_SESSION['username'] ) 
  ){
    header("Location:http://localhost/login-main/login/listing.php");
  }
  $errorhandling= $errorhandling2= "";
  $message = "";
  $validation = "";
  $emailerror = "";
  $passwordErr = "";
  if(isset($_POST['submit'])){
    $test= "";
    $firstname    = $_POST['firstname'];
    $lastname     = $_POST['lastname'];
    $username     = $_POST['username'];
    $email        = $_POST['email'];
    $password     = $_POST['password'];
    $country      = $_POST['country'];
    $qualification = $_POST['ch'];
    // echo "<pre>";
    //   print_r( $_POST);
    // echo"</pre>";
    // die();

    // $qualification= implode(',',$_POST['ch']);

    $qualiCount = count($qualification );
    $i = 1;
    foreach($qualification as $a => $quali){
      $comma = ",";
    if($i ==  $qualiCount){
      $comma = "";
    }
      $test .= $quali.$comma;
      $i++;

    }

     
    $message      = "";
    $userName     = "";
    $test         = "";


    $flag = false; //boolean

    if( empty($firstname)){
      $validation = "This field is required";
      $flag = true;
    }

    if( empty($lastname)){
      $validation = "This field is required";
      $flag = true;
    }    

    if( empty($username)){
      $validation = "This field is required";
      $flag = true;
    }

    if( empty($email)){
      $validation = "This field is required";
      $flag = true;
    } 

    if( empty($country)){
      $validation = "This field is required";
      $flag = true;
    }


    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailerror= "Invalid email format";
    }else{

    if( empty($password)){
      $validation = "This field is required";
      $flag = true;
    }elseif(strlen($password) < '8') {
      $passwordErr = "Your Password Must Contain At Least 8 Characters!";
    }
    elseif(!preg_match("#[0-9]+#",$password)) {
      $passwordErr = "Your Password Must Contain At Least 1 Number!";
    }
    elseif(!preg_match("#[A-Z]+#",$password)) {
      $passwordErr = "Your Password Must Contain At Least 1 Capital Letter!";
    }
    elseif(!preg_match("#[a-z]+#",$password)) {
      $passwordErr = "Your Password Must Contain At Least 1 Lowercase Letter!";
    }else{
    if( $flag == false ){
      $userValidation = mysqli_query($mysql,"SELECT * FROM `".TABLE."` WHERE `username`='$username'");
      $userExists     = mysqli_fetch_all($userValidation, MYSQLI_ASSOC);
      $countRow       = count( $userExists );

    if( $countRow > 0 ){
      $message = "username already taken, try with another one";
      $flag    = true;
    }

    if( $flag == false ){
    // $custom = "";
    // foreach ($qualification as $values){
    //   $custom .= $values;
    // }

    // $test = str_replace('r',',',$custom);

    // echo "<pre>";
    //  print_r($test );
    // echo "</pre>";
    //   die();


    $sql= "INSERT INTO 
    `".TABLE."`(`firstname`, `lastname`, `username`, `email`,`country`, `password`,`qualification`,`status`)  
    VALUES 
    ('".$firstname."', '".$lastname."', '".$username."', '".$email."', '".$country ."', '".$password."','".$test."','customer')";
    $query= mysqli_query($mysql, $sql);
    //var_dump($query); 
    if($query==false){
      $message = mysqli_error($mysql)."<br>"."There is an error to insert data";
    }else{
    header("Location: http://localhost/login-main/login/login/login.php");
    }
    }
    }
    }
    }
  }
  include '../login/header.php';
  include './form.php';
?>