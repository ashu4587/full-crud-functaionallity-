<div style= "background: linear-gradient(to left, #00ccff 0%, #ff00ff 100%); margin-bottom:-40px; height:1250px;"> 
  <div class="col-sm-10" style="margin:0px 100px; text-align: center;">
    <h1> SIGN UP HERE </h1>
  </div>

  <div class="col-sm-5" style="margin: 40px 460px;">
    <form action="" method="post">
      <div class="message-1" style= "text-align:center; width:400px; margin:auto;">
        <?php echo $message = isset($message) ? $message : ''; ?>
      </div>
      <div class="form-group">
        <label for="name">Firstname</label>
        <input type= "text" class= "form-control" name="firstname"  placeholder= "Enter your first name here" value="<?php echo empty($_POST['firstname']) ? '' :($_POST['firstname']) ?>"><br>
        <span>
          <?php
            if( !empty($validation)){
              echo $validation;
            } 
          ?>
        </span> 
      </div></br>
      <div class="form-group">
        <label for="name">Lastname</label>
        <input type= "text" class= "form-control" name="lastname"  placeholder= "Enter your last name here" value="<?php echo empty($_POST['lastname']) ? '' :($_POST['lastname']) ?>"><br>
        <span>
          <?php
            if( !empty($validation)){
              echo $validation;
            } 
          ?>
        </span>
      </div></br>
        <div class="form-group">
        <label for="username">Username</label>
        <input type= "text" class= "form-control" name="username"  placeholder= "Enter your username here" value="<?php echo empty($_POST['username']) ? '' :($_POST['username']) ?>">
        <span>
          <?php
            if( !empty($validation)){
              echo $validation;
            } 
          ?>
        </span>
      </div></br></br>
      <div class="form-group">
        <label for="email">Email</label>
        <input type= "text" class= "form-control" name="email"  placeholder= "Enter your email here" value="<?php echo empty($_POST['email']) ? '' :($_POST['email']) ?>">
        <?php //echo $emailerror; ?>

        <span>      
        <?php
          echo $emailerror;
          if( !empty($validation)){
            echo $validation;
          } 
        ?>
        </span>
      </div></br></br>
   
      <div class="form-group">
        <label for="country">Country</label>
        <input type= "text" class= "form-control" name="country"  placeholder= "Enter your country here" value="">
        <span>
          <?php
            if( !empty($validation)){
              echo $validation;
            } 
          ?>
        </span>
      </div></br></br>
      </span>
      <div class="form-group">
        <label for="password">Password</label>
        <input type= "password" class= "form-control" name="password"  placeholder= "Enter your password here" value="">
        <span>
          <?php
            if( !empty($validation)){
              echo $validation;
            } 
            echo $passwordErr;
          ?>
        </span> 
      </div></br></br>
      <div class="form-group"; style="text-align:center; margin:10px;">
        <label for="qualification"> <strong>Qualification </strong></label></br>
        <label for="10TH " class="checklabel">10TH <input type="checkbox" class= "form-control" name="ch[]"  value="10TH"></label>
        <label for="12TH" class="checklabel">12TH<input type="checkbox" class="form-control" name="ch[]"   value="12TH"></label>
        <label for="UG" class="checklabel">UG<input type="checkbox" class= "form-control" name="ch[]"  value="UG"></label>
        <label for="PG" class="checklabel"> PG <input type="checkbox" class= "form-control" name="ch[]"  value="PG"></label>
      </div></br></br>
        <span>
          <?php
            if( !empty($validation)){
              echo $validation;
            } 
            // echo $passwordErr;
          ?>
       
      <div class="col-sm-2" style="margin: 0 auto; margin-bottom:-10px">
        <button type= "submit" class= "btn btn-primary" name="submit"   value="submit">SUBMIT</button>
      </div>

    </form>
  </div>
</div>