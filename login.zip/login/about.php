<?php
  include './connection/connection.php';
 
//  $session = mysqli_query($mysql, "SELECT * FROM `".TABLE."` WHERE `id` =".$_SESSION['user_id']);
//  $fetch = mysqli_fetch_assoc($session);
//  echo "<pre>"; 
//  print_r($fetch);
//  echo "</pre>";
  $fetch = userStatus($_SESSION['user_id']);
  include PATH.DS.'login'.DS.'login'.DS.'header.php';
?>
  
       
        <!-- <td><a href= "edit.php?id= <?php echo $value ['id']; ?>">Edit </a>
        <a href="listing.php?id=<?php echo $value['id']; ?>&remove=delete">Delete</a> -->
      </tr> 
    </tbody>
  </table>
</form>
<h2 style="text-align:center"><strong>My Profile</h2> <p style="text-align:center;"> Status:- <?php echo ($fetch['activation'] == '1') ? 'Active <svg height="10" width="10 "><circle cx="5" cy="5" r="3" fill="green" /></svg>' : 'Deactive'; ?> </p> 

<div class="card2">
  <img src="./ab.jpg" alt="John" style="width:100%">
  <h1> <?php echo $fetch['firstname'];  echo "\t".$fetch['lastname'];?></h1>
  <p class="title">Username:- <?php echo $fetch['username'];?></p>
  <p>Email :- <?php echo $fetch['email']; ?> </p>
  <div style="margin: 24px 0;">
    <a href="https://www.instagram.com/accounts/login/"><i class="fa fa-instagram"></i></a> 
    <a href="https://twitter.com/login"><i class="fa fa-twitter"></i></a>  
    <a href="https://www.linkedin.com/login"><i class="fa fa-linkedin"></i></a>  
    <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a> 
  </div>
  <p><a href="http://localhost/login-main/login/logout.php"><button>Logout</button></a></p>
</div> 
</strong>



