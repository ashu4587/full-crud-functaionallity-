<?php
  include './connection/connection.php';
  $sql = "SELECT * FROM `".TABLE."`ORDER BY `id` DESC";
  $table = mysqli_query($mysql, $sql);
  $listing  = mysqli_fetch_all($table, MYSQLI_ASSOC);
//   echo "<pre>";
//   print_r( $listing );
//  echo "</pre>";
?>
<style>
    .table2, th, td { 
    text-align:center;
    margin-top: 10px;
    border:1px solid black;
    background:linear-gradient(to bottom, #0000ff 0%, #99ff99 100%);
   
    }
 </style>

<form>

  <table class="table2" style= " width:100%; length: 100%;">
    <thead>
      <tr>
      <th>ID</th>
      <th>Name</th>
      <th> Username </th> 
      <th> Email </th>
      <th> Password</th>
      <th> created on</th>
      <th> Updated on</th>
      </thead>
      <?php  foreach($listing as $key => $value) {
        //  echo "<pre>";
        //    print_r($value);
        //  echo "</pre>"; 

  ?>
    <tbody >
        <td><?php echo $value['id']; ?> </td>
        <td> <?php echo $value['firstname']; ?> </td>
        <td> <?php echo $value['username']; ?> </td>
        <td> <?php echo $value['email']; ?></td>
        <td> <?php echo $value['password']; ?></td>
        <td> <?php echo $value['created_on']; ?></td> 
        <td> <?php echo $value['updated_on']; ?></td> 
      </tr>
      <?php 
      } 
      ?>
    </tbody>
  </table>
</form>    